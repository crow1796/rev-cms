<?php
namespace App\Http\Controllers\Test;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;

class TestController1 extends Controller
{

	public function home(){
		$viewData = array();
		$viewData['title'] = 'Home';
		$viewData['meta_title'] = '';
		$viewData['meta_description'] = '';
		$viewData['meta_keywords'] = '';
		//revpageblock:
		
		//endrevpageblock
		 return view('pages.test.test.home', $viewData);
	}
}