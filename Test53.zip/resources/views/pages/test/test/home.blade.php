<h1 style="text-align: center;">{{ $title }}</h1>
<p>&nbsp;</p>
<p>Tattoeba kimi no kao ni mukashiyori shiwa ga fuetemo, soredemo iinda</p>
<p>boku ga guitar wo omoiyoni&nbsp;</p>
<p>afurete iru yo</p>
<p>takai koi mo dasesu ni</p>
<p>&nbsp;</p>
<p>Darlin' yume ga kanatta no,</p>
<p>oniai no kotoba ga mitsukarani yo,</p>
<p>Darlin' yume ga kanatta no, aishiteru</p>
<p>&nbsp;</p>
<p>kyou ga main dish de owari no hi ni wa,</p>
<p>&nbsp;</p>
<p>tada zutto zutto soba ni oiteitte yo</p>
<p>&nbsp;</p>
<p>Ne, Darlin' yume ga kanatta no,</p>
<p>oniai no kotoba ga mitsukarani yo,</p>
<p>darlin' yume ga kanatta no, ai ga afurete yuku</p>
<p>&nbsp;</p>
<p>kimi ga boku wo, wasurete shimattemo,</p>
<p>chotto tsurai kedo, soredemo kara,</p>
<p>boku yori saki ni doko ka tooku ni tabedasu koto wa zettai yurusenai kara,</p>
<p>omare kawatta toshitemo deai kata ga sayakutemo mata boku wa kimi ni koisurundayo</p>
<p>boku no kokoro wa, kimi ni itsumo kataomoi,</p>
<p>suki dayo,</p>
<p>wakatte yo, wakatte yo, wakatte yooooooooo~</p>