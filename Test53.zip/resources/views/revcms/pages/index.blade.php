@extends('revcms.layout.master')

@section('content')
	<div class="container-fluid">
		<rev-pages></rev-pages>
	</div>
@endsection