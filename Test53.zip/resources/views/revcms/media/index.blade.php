@extends('revcms.layout.master')

@section('content')
	<div class="container-fluid">
		<rev-media-library></rev-media-library>
	</div>
@endsection