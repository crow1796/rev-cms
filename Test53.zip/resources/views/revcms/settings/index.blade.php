@extends('revcms.layout.master')

@section('content')
	<div class="container-fluid">
		<h3 class="page-header">
			Settings
		</h3>
	</div>
@endsection