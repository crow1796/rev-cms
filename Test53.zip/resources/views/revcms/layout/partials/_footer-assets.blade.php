<script type="text/javascript" src="{{ url('/revcms-deps/sweetalert2/sweetalert2.min.js') }}"></script>
<script type="text/javascript" src="{{ url('/revcms-deps/ace/src/ace.js') }}"></script>
<script type="text/javascript" src="{{ url('/revcms-deps/ace/src/ext-emmet.js') }}"></script>
<script type="text/javascript" src="{{ url('/revcms-deps/emmet-core/emmet.js') }}"></script>
<script type="text/javascript" src="{{ url('/revcms-deps/tinymce/tinymce.min.js') }}"></script>
<script type="text/javascript" src="{{ url('/revcms-deps/rev-assets/js/revcms.js') }}"></script>
<script type="text/javascript" src="{{ url('/revcms-deps/toastr/toastr.min.js') }}"></script>