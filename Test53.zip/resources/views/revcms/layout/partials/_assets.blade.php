<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>{{ $title }} - {{ \Config::get('revcms.title') ? \Config::get('revcms.title') : '' }}</title>
{{-- <link href="https://fonts.googleapis.com/css?family=Raleway:100,600" rel="stylesheet" type="text/css"> --}}
<link rel="stylesheet" type="text/css" href="{{ url('/revcms-deps/font-awesome/css/font-awesome.min.css') }}">
<link rel="stylesheet" type="text/css" href="{{ url('/revcms-deps/sweetalert2/sweetalert2.min.css') }}">
<link rel="stylesheet" type="text/css" href="{{ url('/revcms-deps/toastr/toastr.min.css') }}">
<link rel="stylesheet" type="text/css" href="{{ url('/revcms-deps/animate/animate.css') }}">
<link rel="stylesheet" type="text/css" href="{{ url('/revcms-deps/rev-assets/css/revcms.css') }}">