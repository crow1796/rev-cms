<div class="rev-spinner-wrapper" {{ isset($id) ? 'id=' . $id : '' }}>
	<div class="rev-spinner-text">
		Please wait...
	</div>
	<div class="rev-spinner-container">
		<div class="rev-spinner-large">
			<div class="rev-spinner-mini-circle rev-spinner-mini-circle-1"></div>
			<div class="rev-spinner-mini-circle rev-spinner-mini-circle-2"></div>
			<div class="rev-spinner-mini-circle rev-spinner-mini-circle-3"></div>
			<div class="rev-spinner-mini-circle rev-spinner-mini-circle-4"></div>
			<div class="rev-spinner-mini-circle rev-spinner-mini-circle-5"></div>
		</div>
	</div>
</div>