<!DOCTYPE html>
<html>
	<head>
		<script>
		    window.Laravel = { csrfToken: '{{ csrf_token() }}' };
		    window.base_url = '{{ url('/') }}';
		    window.admin_base_url = '{{ url(trim(config('revcms.uri'), '/')) }}';
		</script>
		@yield('before_header_assets')
		@include('revcms.layout.partials._assets', ['title' => $title])
		@yield('after_header_assets')
	</head>
	<body id="rev-cms-app" class="{{ \Config::get('revcms.show_header') ? '_header-pad' : '' }}">
		<div id="page-wrapper">
			<div class="container">
				@yield('content')
			</div>
		</div>
		@include('revcms.layout.partials._footer')
		@yield('before_footer_assets')
		@include('revcms.layout.partials._footer-assets')
		@yield('after_footer_assets')
	</body>
</html>