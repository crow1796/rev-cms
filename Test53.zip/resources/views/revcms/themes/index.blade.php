@extends('revcms.layout.master')

@section('content')
	<div class="container-fluid">
		<rev-themes></rev-themes>
	</div>
@endsection