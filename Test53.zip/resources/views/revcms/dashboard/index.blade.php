@extends('revcms.layout.master')

@section('content')
	<div class="container-fluid">
		<h3 class="page-header">
			Dashboard
		</h3>
	</div>
@endsection