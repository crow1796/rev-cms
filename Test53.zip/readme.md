# RevCMS - CMS for Laravel
RevCMS is a Content Management System made for Developers and Non-Developers. Every content in a website can be managed by using raw code or WYSIWYG. _**RevCMS is a CMS that writes code for you.**_

## Documentation

#### Table of Contents
[Installation]()

[Introduction]()

[Modules]()

[Router](#router)

[CMS]()

[Theme]()

[Components](#components)

## \# Router

### Custom Admin Menu

By registering custom admin menu you need only to create your custom service provider (read more about laravel's [service providers](http://laravel.com/docs/5.3/providers)) and add it inside your config/app.php:
##### For Example:
###### In your terminal, run:
	php artisan make:provider CustomMenuServiceProvider

###### In your config/app.php, add your service provider:
Make sure to add it after RevCMS' Service Provider.

	RevCMS\RevServiceProvider::class,
	App\Providers\CustomMenuServiceProvider::class,

###### You can register Custom Admin Menu by using the following syntax inside your service provider's register method: 
	\RevCMS::router()
	        ->register('web', array(
	                'uri' => '/custom-menu',
	                'uses' => 'CustomMenuController@index',
	                'type' => 'get',
	                'title' => 'Menu 1',
	                'iconClass' => 'revicon-package',
	                'params' => array(
	                    'middleware' => array(),
	                    ),
	                'children' => array(
	                        array(
	                                'uri' => '/custom-submenu-1',
	                                'uses' => 'CustomMenuController@submenu1',
	                                'type' => 'get',
	                                'title' => 'SubMenu 1',
	                                'params' => array(),
	                            ),
	            ));
###### Arguments:

###### Output:
You can now see your custom menu at the bottom part of the sidebar.

[![ajs](docsimages/custom-menu-sidebar.png)]()

##### For the custom menu panel, you need only to create a new blade file and render it using RevCMS' dashboard module, using the following syntax:
Inside CustomMenuController add the following code:
	
	public function index()
	{
	    return \RevCMS::dashboard()
	                    ->render('custommenu.index', 'Custom Menu 1', 1);
	}
render function accepts 3 arguments, the first argument is your blade file, next is the menu bar title, and the last argument is the menu order.

##### You can now put whatever you want inside your blade file, for example:
	<div class="container-fluid">
		<h1 class="text-center page-header">
			Hello World!
			<small>
				This is our first custom menu.
			</small>
		</h1>
	</div>

##### Output:
[![ajs](docsimages/custom-menu-panel.png)]()

## License

The Laravel framework is open-sourced software licensed under the [MIT license](http://opensource.org/licenses/MIT).
